import { FormEvent, ReactNode, useEffect, useState } from "react";
import {
  Activity,
  ArrowDown,
  ArrowUp,
  Bell,
  Check,
  CheckCheck,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Clock3,
  Command,
  Inbox,
  LayoutDashboard,
  LifeBuoy,
  ListFilter,
  LoaderCircle,
  LogOut,
  MessageSquareText,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  SlidersHorizontal,
  Sparkles,
  Ticket as TicketIcon,
  Users,
  X,
} from "lucide-react";
import { Navigate, useLocation, useMatch, useNavigate } from "react-router-dom";
import { authApi, getAuthToken, setAuthToken, ticketApi, userApi } from "./api";
import type {
  Ticket,
  TicketComment,
  TicketDraft,
  TicketPriority,
  TicketStats,
  TicketStatus,
  User,
  UserRole,
} from "./types";

type StatusFilter = "all" | TicketStatus;
type PriorityFilter = "all" | TicketPriority;
type AuthMode = "login" | "register";

const blankStats: TicketStats = { total: 0, open: 0, inProgress: 0, resolved: 0, closed: 0, highPriority: 0 };
const sessionExpiredEvent = "helpdesk:session-expired";
const statusNames: Record<TicketStatus, string> = {
  open: "Open",
  "in-progress": "In progress",
  resolved: "Resolved",
  closed: "Closed",
};
const roleNames: Record<UserRole, string> = { employee: "Employee", agent: "Agent", admin: "Admin" };

function getInitials(name: string) {
  return name.split(" ").filter(Boolean).slice(0, 2).map((part) => part[0].toUpperCase()).join("");
}

function formattedDate(date: string) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric" }).format(new Date(date));
}

function formattedDateTime(date: string) {
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(date));
}

function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const ticketMatch = useMatch("/tickets/:ticketId");
  const ticketId = ticketMatch?.params.ticketId;
  const isUsersPage = location.pathname === "/users";
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [totalTickets, setTotalTickets] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [stats, setStats] = useState<TicketStats>(blankStats);
  const [users, setUsers] = useState<User[]>([]);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [priorityFilter, setPriorityFilter] = useState<PriorityFilter>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState("");
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    function handleExpiredSession() {
      setUser(null);
      setSelectedTicket(null);
      setTickets([]);
      setError("Your session expired. Please sign in again.");
      navigate("/login", { replace: true });
    }

    window.addEventListener(sessionExpiredEvent, handleExpiredSession);
    return () => window.removeEventListener(sessionExpiredEvent, handleExpiredSession);
  }, [navigate]);

  useEffect(() => {
    if (!getAuthToken()) {
      setAuthLoading(false);
      return;
    }
    void authApi.me()
      .then(({ user: currentUser }) => setUser(currentUser))
      .catch(() => {
        if (getAuthToken()) setError("Could not verify your session. Please sign in again.");
      })
      .finally(() => setAuthLoading(false));
  }, []);

  useEffect(() => {
    if (!user || !ticketId) {
      if (!ticketId) setSelectedTicket(null);
      return;
    }
    let active = true;
    setError("");
    void ticketApi.get(ticketId)
      .then((ticket) => {
        if (active) setSelectedTicket(ticket);
      })
      .catch((ticketError) => {
        if (active) {
          setSelectedTicket(null);
          setError(ticketError instanceof Error ? ticketError.message : "Could not load ticket.");
        }
      });
    return () => {
      active = false;
    };
  }, [user, ticketId]);

  async function loadDashboard(
    query = search,
    status = statusFilter,
    priority = priorityFilter,
    requestedPage = currentPage,
  ) {
    if (!user) return;
    setLoading(true);
    setError("");
    try {
      const [ticketPage, nextStats] = await Promise.all([
        ticketApi.list({ query: query.trim(), status, priority, page: requestedPage, limit: 10 }),
        ticketApi.stats(),
      ]);
      setTickets(ticketPage.tickets);
      setTotalTickets(ticketPage.total);
      setTotalPages(ticketPage.totalPages);
      if (ticketPage.totalPages > 0 && requestedPage > ticketPage.totalPages) {
        setCurrentPage(ticketPage.totalPages);
      }
      setStats(nextStats);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Could not load tickets.");
    } finally {
      setLoading(false);
    }
  }

  async function loadUsers() {
    try {
      setUsers(await userApi.list());
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Could not load users.");
    }
  }

  useEffect(() => {
    if (!user) return;
    const timeout = window.setTimeout(() => void loadDashboard(search), 200);
    return () => window.clearTimeout(timeout);
  }, [user, search, statusFilter, priorityFilter, currentPage]);

  useEffect(() => {
    if (user?.role === "admin" && isUsersPage) void loadUsers();
  }, [user, isUsersPage]);

  useEffect(() => {
    if (!notice) return;
    const timeout = window.setTimeout(() => setNotice(""), 3200);
    return () => window.clearTimeout(timeout);
  }, [notice]);

  async function authenticate(event: FormEvent<HTMLFormElement>, mode: AuthMode) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setSaving(true);
    setError("");
    try {
      const response =
        mode === "register"
          ? await authApi.register(
              String(data.get("name")).trim(),
              String(data.get("email")).trim(),
              String(data.get("password")),
            )
          : await authApi.login(String(data.get("email")).trim(), String(data.get("password")));
      setAuthToken(response.token);
      setUser(response.user);
      navigate("/dashboard", { replace: true });
      setNotice(mode === "register" ? "Your employee account is ready." : `Welcome back, ${response.user.name}.`);
    } catch (authError) {
      setError(authError instanceof Error ? authError.message : "Could not sign in.");
    } finally {
      setSaving(false);
    }
  }

  function signOut() {
    setAuthToken(null);
    setUser(null);
    setTickets([]);
    setSelectedTicket(null);
    setStatusFilter("all");
    setPriorityFilter("all");
    setCurrentPage(1);
    setSearch("");
    navigate("/login", { replace: true });
  }

  function openTicket(ticket: Ticket) {
    setSelectedTicket(ticket);
    navigate(`/tickets/${ticket._id}`);
  }

  async function createTicket(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const draft: TicketDraft = {
      title: String(data.get("title")).trim(),
      description: String(data.get("description")).trim(),
      priority: String(data.get("priority")) as TicketPriority,
    };
    setSaving(true);
    setError("");
    try {
      await ticketApi.create(draft);
      setIsCreateOpen(false);
      setNotice("Ticket created successfully.");
      await loadDashboard();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Could not create ticket.");
    } finally {
      setSaving(false);
    }
  }

  async function changeStatus(ticket: Ticket, status: TicketStatus) {
    if (ticket.status === status) return;
    setSaving(true);
    setError("");
    try {
      const updated = await ticketApi.update(ticket._id, { status });
      setSelectedTicket(updated);
      setNotice(`Ticket moved to ${statusNames[status].toLowerCase()}.`);
      await loadDashboard();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Could not update ticket.");
    } finally {
      setSaving(false);
    }
  }

  async function assignToMe(ticket: Ticket) {
    setSaving(true);
    setError("");
    try {
      const updated = await ticketApi.assignToMe(ticket._id);
      setSelectedTicket(updated);
      setNotice("Ticket assigned to you.");
      await loadDashboard();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Could not assign ticket.");
    } finally {
      setSaving(false);
    }
  }

  async function addComment(event: FormEvent<HTMLFormElement>, ticket: Ticket) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const text = String(data.get("comment")).trim();
    if (!text) return;
    setSaving(true);
    setError("");
    try {
      const updated = await ticketApi.comment(ticket._id, text);
      setSelectedTicket(updated);
      setNotice("Reply added.");
      await loadDashboard();
    } catch (commentError) {
      setError(commentError instanceof Error ? commentError.message : "Could not add comment.");
    } finally {
      setSaving(false);
    }
  }

  async function deleteTicket(ticket: Ticket) {
    if (ticket.status !== "open" || ticket.createdBy._id !== user?.id) return;
    if (!window.confirm(`Delete “${ticket.title}”? This cannot be undone.`)) return;
    setSaving(true);
    setError("");
    try {
      await ticketApi.remove(ticket._id);
      setSelectedTicket(null);
      navigate("/dashboard");
      setNotice("Ticket deleted.");
      await loadDashboard();
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : "Could not delete ticket.");
    } finally {
      setSaving(false);
    }
  }

  async function updateRole(target: User, role: UserRole) {
    if (target.role === role) return;
    setSaving(true);
    setError("");
    try {
      const updated = await userApi.updateRole(target.id, role);
      setUsers((current) => current.map((item) => (item.id === updated.id ? updated : item)));
      if (user?.id === updated.id) {
        setUser(updated);
        if (updated.role !== "admin") navigate("/dashboard", { replace: true });
      }
      setNotice(`${updated.name} is now an ${roleNames[role].toLowerCase()}.`);
    } catch (roleError) {
      setError(roleError instanceof Error ? roleError.message : "Could not update user role.");
    } finally {
      setSaving(false);
    }
  }

  if (authLoading) {
    return <div className="auth-loading"><LoaderCircle className="spinner" size={22} /> Checking your session...</div>;
  }
  if (!user) {
    if (location.pathname === "/login" || location.pathname === "/signup") {
      return <AuthScreen onSubmit={authenticate} busy={saving} error={error} clearError={() => setError("")} mode={location.pathname === "/signup" ? "register" : "login"} onModeChange={(mode) => navigate(mode === "register" ? "/signup" : "/login")} />;
    }
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }
  if (location.pathname === "/login" || location.pathname === "/signup") {
    return <Navigate to="/dashboard" replace />;
  }
  if (location.pathname !== "/dashboard" && location.pathname !== "/users" && !ticketMatch) {
    return <Navigate to="/dashboard" replace />;
  }
  if (isUsersPage && user.role !== "admin") {
    return <Navigate to="/dashboard" replace />;
  }

  const isStaff = user.role === "agent" || user.role === "admin";
  const tabs: { label: string; value: StatusFilter; count: number }[] = [
    { label: "All tickets", value: "all", count: stats.total },
    { label: "Open", value: "open", count: stats.open },
    { label: "In progress", value: "in-progress", count: stats.inProgress },
    { label: "Resolved", value: "resolved", count: stats.resolved },
    { label: "Closed", value: "closed", count: stats.closed },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="workspace-picker">
          <div className="workspace-avatar">{getInitials(user.name).slice(0, 1)}</div>
          <div className="workspace-text"><strong>HelpDesk Lite</strong></div>
        </div>
        <div className="sidebar-label">WORKSPACE</div>
        <nav className="sidebar-nav" aria-label="Main navigation">
          <button type="button" className={`nav-item ${!isUsersPage ? "active" : ""}`} onClick={() => navigate("/dashboard")}><TicketIcon size={17} /> {isStaff ? "All tickets" : "My tickets"} <span className="nav-count">{stats.open}</span></button>
          {user.role === "admin" && <button type="button" className={`nav-item ${isUsersPage ? "active" : ""}`} onClick={() => navigate("/users")}><Users size={17} /> Users</button>}
        </nav>
        <div className="sidebar-bottom">
          <button type="button" className="profile-button" onClick={signOut} title="Sign out">
            <span className="profile-avatar">{getInitials(user.name)}</span>
            <span className="profile-copy"><strong>{user.name}</strong><small>{roleNames[user.role]} · Sign out</small></span>
            <LogOut size={16} />
          </button>
        </div>
      </aside>

      <main className="main-content" id="tickets">
        <header className="topbar">
          <div className="breadcrumbs"><span>{isUsersPage ? "Administration" : "Workspace"}</span><ChevronRight size={14} /><strong>{isUsersPage ? "User roles" : isStaff ? "All tickets" : "My tickets"}</strong></div>
        </header>

        <div className="page-content">
          {isUsersPage ? (
            <UserManagement users={users} currentUser={user} busy={saving} onRoleChange={updateRole} onRefresh={() => void loadUsers()} />
          ) : (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow"><span className="eyebrow-line" /> {isStaff ? "SUPPORT CENTER" : "EMPLOYEE PORTAL"}</div>
                  <h1>{isStaff ? "Your team’s tickets, " : "Your requests, "}<span>{isStaff ? "under control." : "all in one place."}</span></h1>
                  <p className="page-subtitle">{isStaff ? "Keep requests moving and give every customer a clear answer." : "Raise a request, add details, and follow the conversation here."}</p>
                </div>
                <button className="primary-button" type="button" onClick={() => { setError(""); setIsCreateOpen(true); }}><Plus size={17} /> New ticket</button>
              </div>

              {error && <ErrorBanner error={error} dismiss={() => setError("")} />}

              <section className="stats-grid" aria-label="Ticket overview">
                <StatCard label="Total tickets" value={stats.total} icon={<Inbox size={18} />} tone="lavender" note={isStaff ? "Across all requests" : "Your requests"} />
                <StatCard label="Open tickets" value={stats.open} icon={<Clock3 size={18} />} tone="amber" note="Waiting for a reply" />
                <StatCard label="In progress" value={stats.inProgress} icon={<Activity size={18} />} tone="blue" note="Being worked on" />
                <StatCard label="Resolved" value={stats.resolved} icon={<CheckCheck size={18} />} tone="green" note="Nicely done" />
              </section>

              <section className="ticket-panel">
                <div className="panel-heading">
                  <div><h2>{isStaff ? "All tickets" : "My tickets"} <span className="panel-count">{stats.total}</span></h2><p>{isStaff ? "Search, assign, and resolve incoming support requests." : "Track your requests and continue the conversation."}</p></div>
                  <button type="button" className="secondary-button" onClick={() => void loadDashboard()} disabled={loading}><SlidersHorizontal size={15} /> Refresh</button>
                </div>
                <div className="ticket-toolbar">
                  <div className="ticket-tabs" role="tablist" aria-label="Filter tickets by status">
                    {tabs.map((tab) => <button className={`ticket-tab ${statusFilter === tab.value ? "selected" : ""}`} key={tab.value} type="button" role="tab" aria-selected={statusFilter === tab.value} onClick={() => { setCurrentPage(1); setStatusFilter(tab.value); }}>{tab.label}<span>{tab.count}</span></button>)}
                  </div>
                  <div className="table-actions">
                    <label className="search-field"><Search size={16} /><input value={search} onChange={(event) => { setCurrentPage(1); setSearch(event.target.value); }} placeholder="Search tickets..." aria-label="Search tickets" /><kbd><Command size={11} /> K</kbd></label>
                    <label className="priority-filter"><ListFilter size={15} /><select aria-label="Filter tickets by priority" value={priorityFilter} onChange={(event) => { setCurrentPage(1); setPriorityFilter(event.target.value as PriorityFilter); }}><option value="all">All priorities</option><option value="low">Low priority</option><option value="medium">Medium priority</option><option value="high">High priority</option></select></label>
                  </div>
                </div>
                <div className="ticket-table-wrap">
                  <table className="ticket-table">
                    <thead><tr><th><span className="checkbox" aria-hidden="true" /></th><th>Ticket</th><th>{isStaff ? "Customer" : "Description"}</th>{isStaff && <th>Assignee</th>}<th>Priority</th><th>Status</th><th>Created</th><th aria-label="Actions" /></tr></thead>
                    <tbody>
                      {loading ? (
                        <tr><td className="table-state" colSpan={isStaff ? 8 : 7}><LoaderCircle className="spinner" size={20} /> Loading tickets...</td></tr>
                      ) : tickets.length === 0 ? (
                        <tr><td className="table-state empty-state" colSpan={isStaff ? 8 : 7}>
                          <span className="empty-icon"><Inbox size={22} /></span>
                          <strong>{search || statusFilter !== "all" || priorityFilter !== "all" ? "No tickets match your filters" : "All clear for now"}</strong>
                          <span>{search || statusFilter !== "all" || priorityFilter !== "all" ? "Try another search or filter." : "Create a ticket to start tracking support requests."}</span>
                          {!search && statusFilter === "all" && priorityFilter === "all" && <button className="text-button" type="button" onClick={() => setIsCreateOpen(true)}><Plus size={15} /> Create your first ticket</button>}
                        </td></tr>
                      ) : tickets.map((ticket) => (
                        <tr key={ticket._id} onClick={() => openTicket(ticket)} className="ticket-row">
                          <td><span className="checkbox" aria-hidden="true" /></td>
                          <td className="ticket-cell"><span className="ticket-symbol"><TicketIcon size={15} /></span><span className="ticket-title-wrap"><strong>{ticket.title}</strong><small>#{ticket._id.slice(-6).toUpperCase()}</small></span></td>
                          {isStaff ? (
                            <>
                              <td><div className="customer-cell"><span className={`customer-avatar avatar-${ticket.createdBy.name.length % 5}`}>{getInitials(ticket.createdBy.name)}</span><span><strong>{ticket.createdBy.name}</strong><small>{ticket.createdBy.email}</small></span></div></td>
                              <td className="assignee-cell">{ticket.assignedTo ? <span className="assignee-chip">{getInitials(ticket.assignedTo.name)} {ticket.assignedTo.name}</span> : <span className="unassigned">Unassigned</span>}</td>
                            </>
                          ) : <td className="date-cell description-cell">{ticket.description}</td>}
                          <td><PriorityBadge priority={ticket.priority} /></td><td><StatusBadge status={ticket.status} /></td><td className="date-cell">{formattedDate(ticket.createdAt)}</td>
                          <td><button className="row-more" type="button" aria-label={`Open ${ticket.title}`} onClick={(event) => { event.stopPropagation(); openTicket(ticket); }}><MoreHorizontal size={18} /></button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="table-footer"><span>Showing <strong>{totalTickets ? (currentPage - 1) * 10 + 1 : 0}–{Math.min(currentPage * 10, totalTickets)}</strong> of <strong>{totalTickets}</strong> tickets</span><div className="pagination"><button type="button" aria-label="Previous page" disabled={currentPage <= 1 || loading} onClick={() => setCurrentPage((value) => value - 1)}><ChevronLeft size={16} /></button><span>{currentPage} / {Math.max(totalPages, 1)}</span><button type="button" aria-label="Next page" disabled={currentPage >= totalPages || loading} onClick={() => setCurrentPage((value) => value + 1)}><ChevronRight size={16} /></button></div></div>
              </section>
            </>
          )}
          {error && isUsersPage && <ErrorBanner error={error} dismiss={() => setError("")} />}
        </div>
      </main>

      {isCreateOpen && <CreateTicketModal busy={saving} onClose={() => setIsCreateOpen(false)} onSubmit={createTicket} />}
      {selectedTicket && user && <TicketDetailModal ticket={selectedTicket} user={user} busy={saving} onClose={() => { setSelectedTicket(null); navigate("/dashboard"); }} onAssign={() => void assignToMe(selectedTicket)} onStatusChange={(status) => void changeStatus(selectedTicket, status)} onComment={(event) => void addComment(event, selectedTicket)} onDelete={() => void deleteTicket(selectedTicket)} />}
      {notice && <div className="toast" role="status"><span><Check size={14} /></span>{notice}<button type="button" onClick={() => setNotice("")} aria-label="Dismiss notification"><X size={15} /></button></div>}
    </div>
  );
}

function AuthScreen({ onSubmit, busy, error, clearError, mode, onModeChange }: { onSubmit: (event: FormEvent<HTMLFormElement>, mode: AuthMode) => void; busy: boolean; error: string; clearError: () => void; mode: AuthMode; onModeChange: (mode: AuthMode) => void }) {
  return (
    <main className="auth-page">
      <section className="auth-card">
        <a className="brand auth-brand" href="#" aria-label="HelpDesk Lite home"><span className="brand-mark"><LifeBuoy size={20} /></span><span className="brand-copy">helpdesk<span>lite</span></span></a>
        <div className="auth-heading"><div className="eyebrow"><span className="eyebrow-line" /> INTERNAL SUPPORT</div><h1>{mode === "login" ? "Welcome back." : "Create your account."}</h1><p>{mode === "login" ? "Sign in to view and manage your support tickets." : "Employee accounts can raise and follow support requests."}</p></div>
        {error && <ErrorBanner error={error} dismiss={clearError} />}
        <form className="auth-form" onSubmit={(event) => onSubmit(event, mode)}>
          {mode === "register" && <label className="form-field"><span>Your name</span><input name="name" autoComplete="name" minLength={2} maxLength={100} title="Enter a name that is not only spaces." placeholder="Alex Morgan" required /></label>}
          <label className="form-field"><span>Work email</span><input name="email" type="email" autoComplete="email" placeholder="you@company.com" required /></label>
          <label className="form-field"><span>Password</span><input name="password" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={mode === "register" ? 12 : undefined} maxLength={72} placeholder={mode === "register" ? "At least 12 characters" : "Enter your password"} required /></label>
          <button className="primary-button auth-submit" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spinner" size={16} /> : null}{mode === "login" ? "Sign in" : "Create employee account"}</button>
        </form>
        <p className="auth-switch">{mode === "login" ? "New to HelpDesk Lite?" : "Already have an account?"} <button type="button" onClick={() => { clearError(); onModeChange(mode === "login" ? "register" : "login"); }}>{mode === "login" ? "Create an account" : "Sign in"}</button></p>
      </section>
    </main>
  );
}

function CreateTicketModal({ busy, onClose, onSubmit }: { busy: boolean; onClose: () => void; onSubmit: (event: FormEvent<HTMLFormElement>) => void }) {
  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }}>
      <section className="ticket-modal" role="dialog" aria-modal="true" aria-labelledby="create-title">
        <div className="modal-heading"><div><span className="modal-icon"><Plus size={18} /></span><div><h2 id="create-title">Create a ticket</h2><p>Share what happened so your support team can help.</p></div></div><button type="button" className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={18} /></button></div>
        <form onSubmit={onSubmit}>
          <div className="form-grid">
            <label className="form-field form-full"><span>Title (5–120 characters)</span><input name="title" placeholder="e.g. VPN issue" minLength={5} maxLength={120} title="Enter a title that is not only spaces." required autoFocus /></label>
            <label className="form-field form-full"><span>Priority</span><select name="priority" defaultValue="medium"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option></select></label>
            <label className="form-field form-full"><span>Description</span><textarea name="description" placeholder="Share a few details about your request..." maxLength={5000} rows={4} onInput={(event) => event.currentTarget.setCustomValidity(event.currentTarget.value.trim() ? "" : "Enter a description that is not only spaces.")} required /></label>
          </div>
          <div className="modal-footer"><span><span className="required-dot" /> Required fields</span><div><button className="secondary-button" type="button" onClick={onClose} disabled={busy}>Cancel</button><button className="primary-button" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spinner" size={16} /> : <Plus size={16} />} Create ticket</button></div></div>
        </form>
      </section>
    </div>
  );
}

function TicketDetailModal({ ticket, user, busy, onClose, onAssign, onStatusChange, onComment, onDelete }: { ticket: Ticket; user: User; busy: boolean; onClose: () => void; onAssign: () => void; onStatusChange: (status: TicketStatus) => void; onComment: (event: FormEvent<HTMLFormElement>) => void; onDelete: () => void }) {
  const isStaff = user.role === "agent" || user.role === "admin";
  return (
    <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget && !busy) onClose(); }}>
      <section className="ticket-modal detail-modal" role="dialog" aria-modal="true" aria-labelledby="detail-title">
        <div className="modal-heading"><div><span className="modal-icon"><TicketIcon size={18} /></span><div><span className="detail-id">TICKET #{ticket._id.slice(-6).toUpperCase()}</span><h2 id="detail-title">{ticket.title}</h2></div></div><button type="button" className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={18} /></button></div>
        <div className="detail-content">
          <div className="detail-badges"><StatusBadge status={ticket.status} /><PriorityBadge priority={ticket.priority} /></div>
          {isStaff ? (
            <div className="agent-controls">
              <div><span className="control-label">Assigned to</span><strong>{ticket.assignedTo?.name ?? "No one yet"}</strong></div>
              <button type="button" className="secondary-button" onClick={onAssign} disabled={busy || ticket.assignedTo?._id === user.id}>{ticket.assignedTo?._id === user.id ? <Check size={14} /> : <Users size={14} />}{ticket.assignedTo?._id === user.id ? "Assigned to you" : "Assign to me"}</button>
              <label className="detail-priority-control"><span>Status</span><select value={ticket.status} disabled={busy} onChange={(event) => onStatusChange(event.target.value as TicketStatus)}><option value="open">Open</option><option value="in-progress">In progress</option><option value="resolved">Resolved</option><option value="closed">Closed</option></select></label>
            </div>
          ) : <div className="view-only-message"><CircleHelp size={15} /> Only support agents can change the status of this ticket.</div>}
          <div className="detail-section"><h3>Description</h3><p className="description-copy">{ticket.description}</p></div>
          <div className="detail-section"><h3>{isStaff ? "Customer" : "Submitted by you"}</h3><div className="detail-customer"><span className={`customer-avatar avatar-${ticket.createdBy.name.length % 5}`}>{getInitials(ticket.createdBy.name)}</span><span><strong>{ticket.createdBy.name}</strong><a href={`mailto:${ticket.createdBy.email}`}>{ticket.createdBy.email}</a></span></div></div>
          <div className="detail-section"><h3>Assigned to</h3><p className="description-copy">{ticket.assignedTo?.name ?? "Unassigned"}</p></div>
          <section className="comments-section"><div className="comments-title"><h3>Conversation</h3><span>{ticket.comments.length}</span></div>
            {ticket.comments.length === 0 ? <p className="no-comments">No replies yet. Add a comment to keep the conversation going.</p> : <div className="comment-list">{ticket.comments.map((comment) => <CommentItem key={comment._id} comment={comment} />)}</div>}
            <form className="comment-form" onSubmit={onComment}><textarea name="comment" rows={2} maxLength={2000} onInput={(event) => event.currentTarget.setCustomValidity(event.currentTarget.value.trim() ? "" : "Enter a comment that is not only spaces.")} placeholder="Write a reply..." required /><button className="primary-button" type="submit" disabled={busy}><MessageSquareText size={15} /> Reply</button></form>
          </section>
          <div className="detail-meta"><span>Created {formattedDateTime(ticket.createdAt)}</span><span>Updated {formattedDateTime(ticket.updatedAt)}</span></div>
        </div>
        <div className="modal-footer detail-footer">{!isStaff && ticket.createdBy._id === user.id && ticket.status === "open" ? <button className="delete-button" type="button" onClick={onDelete} disabled={busy}>Delete ticket</button> : <span>Ticket updates are visible to the requester and support team.</span>}<button className="secondary-button" type="button" onClick={onClose}>Close</button></div>
      </section>
    </div>
  );
}

function CommentItem({ comment }: { comment: TicketComment }) {
  return <article className="comment-item"><span className={`customer-avatar avatar-${comment.author.name.length % 5}`}>{getInitials(comment.author.name)}</span><div className="comment-body"><div className="comment-author"><strong>{comment.author.name}</strong><span className={`role-chip role-${comment.author.role}`}>{roleNames[comment.author.role]}</span><time>{formattedDateTime(comment.createdAt)}</time></div><p>{comment.text}</p></div></article>;
}

function UserManagement({ users, currentUser, busy, onRoleChange, onRefresh }: { users: User[]; currentUser: User; busy: boolean; onRoleChange: (user: User, role: UserRole) => void; onRefresh: () => void }) {
  return (
    <>
      <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> ADMINISTRATION</div><h1>Manage <span>user roles.</span></h1><p className="page-subtitle">Choose who can work on support requests or manage this workspace.</p></div><button className="secondary-button" type="button" onClick={onRefresh}><SlidersHorizontal size={15} /> Refresh users</button></div>
      <section className="ticket-panel users-panel">
        <div className="panel-heading"><div><h2>Workspace users <span className="panel-count">{users.length}</span></h2><p>New accounts always join as employees. Promote trusted teammates as needed.</p></div></div>
        <div className="ticket-table-wrap"><table className="ticket-table users-table"><thead><tr><th>User</th><th>Role</th><th>Joined</th><th /></tr></thead><tbody>
          {users.map((target) => <tr key={target.id}><td><div className="customer-cell"><span className={`customer-avatar avatar-${target.name.length % 5}`}>{getInitials(target.name)}</span><span><strong>{target.name}{target.id === currentUser.id && <small className="you-label">You</small>}</strong><small>{target.email}</small></span></div></td><td><label className="role-select-label"><select aria-label={`Role for ${target.name}`} value={target.role} disabled={busy} onChange={(event) => onRoleChange(target, event.target.value as UserRole)}><option value="employee">Employee</option><option value="agent">Agent</option><option value="admin">Admin</option></select></label></td><td className="date-cell">{target.createdAt ? formattedDate(target.createdAt) : "—"}</td><td>{target.id === currentUser.id && <span className="current-user-label">Current user</span>}</td></tr>)}
          {!users.length && <tr><td colSpan={4} className="table-state">No users found.</td></tr>}
        </tbody></table></div>
      </section>
    </>
  );
}

function ErrorBanner({ error, dismiss }: { error: string; dismiss: () => void }) {
  return <div className="error-banner" role="alert">{error}<button type="button" onClick={dismiss} aria-label="Dismiss error"><X size={15} /></button></div>;
}

function StatCard({ label, value, icon, tone, note }: { label: string; value: number; icon: ReactNode; tone: string; note: string }) {
  return <article className="stat-card"><div className="stat-top"><span className={`stat-icon ${tone}`}>{icon}</span><button type="button" className="stat-menu" aria-label={`${label} details`}><MoreHorizontal size={18} /></button></div><strong className="stat-value">{value.toLocaleString()}</strong><div className="stat-bottom"><span>{label}</span><small>{note}</small></div></article>;
}

function PriorityBadge({ priority }: { priority: TicketPriority }) {
  const Icon = priority === "high" ? ArrowUp : priority === "low" ? ArrowDown : Activity;
  return <span className={`priority-badge priority-${priority}`}><Icon size={13} />{priority[0].toUpperCase() + priority.slice(1)}</span>;
}

function StatusBadge({ status }: { status: TicketStatus }) {
  return <span className={`status-badge status-${status}`}><span />{statusNames[status]}</span>;
}

export default App;
