export type TicketStatus = "open" | "in-progress" | "resolved" | "closed";
export type TicketPriority = "low" | "medium" | "high";
export type UserRole = "employee" | "agent" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  createdAt?: string;
}

export interface TicketUser {
  _id: string;
  name: string;
  email: string;
  role: UserRole;
}

export interface TicketComment {
  _id: string;
  author: Pick<TicketUser, "_id" | "name" | "role">;
  text: string;
  createdAt: string;
}

export interface Ticket {
  _id: string;
  title: string;
  description: string;
  priority: TicketPriority;
  status: TicketStatus;
  createdBy: TicketUser;
  assignedTo: TicketUser | null;
  comments: TicketComment[];
  createdAt: string;
  updatedAt: string;
}

export interface TicketPage {
  tickets: Ticket[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface TicketStats {
  total: number;
  open: number;
  inProgress: number;
  resolved: number;
  closed: number;
  highPriority: number;
}

export type TicketDraft = Pick<Ticket, "title" | "description" | "priority">;

export interface AuthResponse {
  token: string;
  user: User;
}
