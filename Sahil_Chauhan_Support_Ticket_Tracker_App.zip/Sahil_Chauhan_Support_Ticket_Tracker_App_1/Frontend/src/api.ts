import type {
  AuthResponse,
  Ticket,
  TicketDraft,
  TicketPage,
  TicketStats,
  TicketStatus,
  User,
  UserRole,
} from "./types";

const API_URL = import.meta.env.VITE_API_URL ?? "http://localhost:5000/api";
const TOKEN_KEY = "helpdesk-lite-token";
const SESSION_EXPIRED_EVENT = "helpdesk:session-expired";

export function setAuthToken(token: string | null) {
  if (token) sessionStorage.setItem(TOKEN_KEY, token);
  else sessionStorage.removeItem(TOKEN_KEY);
}

export function getAuthToken() {
  return sessionStorage.getItem(TOKEN_KEY);
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const token = getAuthToken();
  const response = await fetch(`${API_URL}${path}`, {
    ...init,
    headers: {
      ...(init?.body ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...init?.headers,
    },
  });

  if (!response.ok) {
    const body = (await response.json().catch(() => null)) as { message?: string } | null;
    if (
      response.status === 401 &&
      token &&
      !path.startsWith("/auth/login") &&
      !path.startsWith("/auth/register")
    ) {
      setAuthToken(null);
      window.dispatchEvent(new Event(SESSION_EXPIRED_EVENT));
    }
    throw new Error(body?.message ?? `Request failed (${response.status})`);
  }

  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export const authApi = {
  login: (email: string, password: string) =>
    request<AuthResponse>("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),
  register: (name: string, email: string, password: string) =>
    request<AuthResponse>("/auth/register", {
      method: "POST",
      body: JSON.stringify({ name, email, password }),
    }),
  me: () => request<{ user: User }>("/auth/me"),
};

export const ticketApi = {
  get: (id: string) => request<Ticket>(`/tickets/${id}`),
  list: (options: { query: string; status: string; priority: string; page: number; limit: number }) => {
    const params = new URLSearchParams({
      q: options.query,
      status: options.status,
      priority: options.priority,
      page: String(options.page),
      limit: String(options.limit),
    });
    return request<TicketPage>(`/tickets?${params.toString()}`);
  },
  stats: () => request<TicketStats>("/tickets/stats"),
  create: (ticket: TicketDraft) =>
    request<Ticket>("/tickets", { method: "POST", body: JSON.stringify(ticket) }),
  update: (id: string, changes: { status?: TicketStatus }) =>
    request<Ticket>(`/tickets/${id}`, { method: "PATCH", body: JSON.stringify(changes) }),
  assignToMe: (id: string) => request<Ticket>(`/tickets/${id}/assignment`, { method: "PATCH" }),
  comment: (id: string, text: string) =>
    request<Ticket>(`/tickets/${id}/comments`, { method: "POST", body: JSON.stringify({ text }) }),
  remove: (id: string) => request<void>(`/tickets/${id}`, { method: "DELETE" }),
};

export const userApi = {
  list: () => request<User[]>("/users"),
  updateRole: (id: string, role: UserRole) =>
    request<User>(`/users/${id}/role`, { method: "PATCH", body: JSON.stringify({ role }) }),
};
