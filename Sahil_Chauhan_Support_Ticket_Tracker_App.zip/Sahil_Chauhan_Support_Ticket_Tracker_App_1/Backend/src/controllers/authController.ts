import { NextFunction, Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import mongoose from "mongoose";
import { AuthenticatedUser, jwtSecret } from "../middleware/auth";
import { User, UserRole, userRoles } from "../models/User";

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const passwordMinLength = 12;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function publicUser(user: AuthenticatedUser) {
  return user;
}

function issueToken(user: AuthenticatedUser) {
  return jwt.sign({}, jwtSecret(), { subject: user.id, expiresIn: "8h" });
}

function authResponse(user: AuthenticatedUser) {
  return { token: issueToken(user), user: publicUser(user) };
}

function credentialsError(res: Response) {
  res.status(401).json({ message: "Email or password is incorrect" });
}

export async function register(req: Request, res: Response, next: NextFunction) {
  try {
    if (!isRecord(req.body)) {
      res.status(400).json({ message: "Request body must be a JSON object" });
      return;
    }
    if (Object.keys(req.body).some((key) => !["name", "email", "password"].includes(key))) {
      res.status(400).json({ message: "Only name, email, and password can be provided" });
      return;
    }
    const { name, email, password } = req.body;
    if (
      typeof name !== "string" ||
      name.trim().length < 2 ||
      name.trim().length > 100 ||
      typeof email !== "string" ||
      !emailPattern.test(email.trim()) ||
      typeof password !== "string" ||
      password.length < passwordMinLength ||
      Buffer.byteLength(password, "utf8") > 72
    ) {
      res.status(400).json({
        message: "Enter a valid name and email. Passwords must be at least 12 characters.",
      });
      return;
    }

    const normalizedEmail = email.trim().toLowerCase();
    if (await User.exists({ email: normalizedEmail })) {
      res.status(409).json({ message: "An account with this email already exists" });
      return;
    }

    const user = await User.create({
      name: name.trim(),
      email: normalizedEmail,
      passwordHash: await bcrypt.hash(password, 12),
      role: "employee",
    });
    res.status(201).json(
      authResponse({ id: user.id, name: user.name, email: user.email, role: user.role }),
    );
  } catch (error) {
    if (error instanceof mongoose.mongo.MongoServerError && error.code === 11000) {
      res.status(409).json({ message: "An account with this email already exists" });
      return;
    }
    next(error);
  }
}

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    if (!isRecord(req.body)) {
      res.status(400).json({ message: "Request body must be a JSON object" });
      return;
    }
    const { email, password } = req.body;
    if (
      typeof email !== "string" ||
      typeof password !== "string" ||
      Buffer.byteLength(password, "utf8") > 72
    ) {
      credentialsError(res);
      return;
    }

    const user = await User.findOne({ email: email.trim().toLowerCase() }).select("+passwordHash");
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      credentialsError(res);
      return;
    }
    res.json(authResponse({ id: user.id, name: user.name, email: user.email, role: user.role }));
  } catch (error) {
    next(error);
  }
}

export function me(req: Request, res: Response) {
  if (!req.user) {
    res.status(401).json({ message: "Sign in to continue" });
    return;
  }
  res.json({ user: publicUser(req.user) });
}

export async function listUsers(_req: Request, res: Response, next: NextFunction) {
  try {
    const users = await User.find().select("name email role createdAt").sort({ name: 1 });
    res.json(users.map((user) => ({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      createdAt: user.createdAt,
    })));
  } catch (error) {
    next(error);
  }
}

export async function updateUserRole(req: Request, res: Response, next: NextFunction) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      res.status(400).json({ message: "Invalid user ID" });
      return;
    }
    if (
      !isRecord(req.body) ||
      Object.keys(req.body).some((key) => key !== "role") ||
      typeof req.body.role !== "string" ||
      !userRoles.includes(req.body.role as UserRole)
    ) {
      res.status(400).json({ message: "Choose employee, agent, or admin" });
      return;
    }

    const target = await User.findById(req.params.id).select("name email role createdAt");
    if (!target) {
      res.status(404).json({ message: "User not found" });
      return;
    }
    const nextRole = req.body.role as UserRole;
    if (target.role === "admin" && nextRole !== "admin") {
      const adminCount = await User.countDocuments({ role: "admin" });
      if (adminCount <= 1) {
        res.status(409).json({ message: "The last administrator cannot be demoted" });
        return;
      }
    }

    target.role = nextRole;
    await target.save();
    res.json({
      id: target.id,
      name: target.name,
      email: target.email,
      role: target.role,
      createdAt: target.createdAt,
    });
  } catch (error) {
    next(error);
  }
}

export async function seedAdmin() {
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  const name = process.env.ADMIN_NAME?.trim() || "HelpDesk Admin";
  if (!email || !emailPattern.test(email) || !password || password.length < passwordMinLength) {
    throw new Error(
      "Set ADMIN_EMAIL and an ADMIN_PASSWORD of at least 12 characters to the first admin.",
    );
  }
  if (Buffer.byteLength(password, "utf8") > 72) {
    throw new Error("ADMIN_PASSWORD must not exceed 72 UTF-8 bytes.");
  }

  const existing = await User.findOne({ email });
  if (existing) {
    if (existing.role !== "admin") {
      throw new Error("ADMIN_EMAIL belongs to a non-admin user; choose another email.");
    }
    return;
  }

  await User.create({
    name,
    email,
    passwordHash: await bcrypt.hash(password, 12),
    role: "admin",
  });
  console.info(`HelpDesk Lite administrator: ${email}`);
}
