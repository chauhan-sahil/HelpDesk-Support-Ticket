import { NextFunction, Request, Response } from "express";
import mongoose from "mongoose";
import { AuthenticatedUser } from "../middleware/auth";
import {
  Ticket,
  ticketPriorities,
  ticketStatuses,
  TicketPriority,
  TicketStatus,
} from "../models/Ticket";

const populatedTicket = {
  path: "createdBy assignedTo comments.author",
  select: "name email role",
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function escapeRegex(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function ticketVisibility(user: AuthenticatedUser) {
  return user.role === "employee" ? { createdBy: user.id } : {};
}

function visibleTicketQuery(id: string, user: AuthenticatedUser) {
  return { _id: id, ...ticketVisibility(user) };
}

function parseId(req: Request, res: Response): string | null {
  const { id } = req.params;
  if (typeof id !== "string" || !mongoose.isValidObjectId(id)) {
    res.status(400).json({ message: "Invalid ticket ID" });
    return null;
  }
  return id;
}

function invalidBody(res: Response) {
  res.status(400).json({ message: "Request body must be a JSON object" });
}

function rejectUnknownFields(body: Record<string, unknown>, fields: string[]) {
  return Object.keys(body).some((field) => !fields.includes(field));
}

export async function listTickets(req: Request, res: Response, next: NextFunction) {
  try {
    const filter: Record<string, unknown> = ticketVisibility(req.user!);
    for (const key of ["status", "priority", "q"]) {
      if (req.query[key] !== undefined && typeof req.query[key] !== "string") {
        res.status(400).json({ message: `${key} must be a single string value` });
        return;
      }
    }
    if (typeof req.query.status === "string" && req.query.status !== "all") {
      if (!ticketStatuses.includes(req.query.status as TicketStatus)) {
        res.status(400).json({ message: "Invalid ticket status" });
        return;
      }
      filter.status = req.query.status;
    }
    if (typeof req.query.priority === "string" && req.query.priority !== "all") {
      if (!ticketPriorities.includes(req.query.priority as TicketPriority)) {
        res.status(400).json({ message: "Invalid ticket priority" });
        return;
      }
      filter.priority = req.query.priority;
    }

    const rawSearch = typeof req.query.q === "string" ? req.query.q.trim() : "";
    if (rawSearch.length > 100) {
      res.status(400).json({ message: "Search query must be 100 characters or fewer" });
      return;
    }
    if (rawSearch) filter.title = new RegExp(escapeRegex(rawSearch), "i");

    const page = req.query.page === undefined ? 1 : Number(req.query.page);
    const limit = req.query.limit === undefined ? 10 : Number(req.query.limit);
    if (!Number.isSafeInteger(page) || page < 1) {
      res.status(400).json({ message: "Page must be a positive integer" });
      return;
    }
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) {
      res.status(400).json({ message: "Limit must be an integer between 1 and 100" });
      return;
    }

    const [tickets, total] = await Promise.all([
      Ticket.find(filter)
        .populate(populatedTicket)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
      Ticket.countDocuments(filter),
    ]);

    res.json({
      tickets,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    next(error);
  }
}

export async function getTicketStats(req: Request, res: Response, next: NextFunction) {
  try {
    const visibleFilter = ticketVisibility(req.user!);
    const [total, open, inProgress, resolved, closed, highPriority] = await Promise.all([
      Ticket.countDocuments(visibleFilter),
      Ticket.countDocuments({ ...visibleFilter, status: "open" }),
      Ticket.countDocuments({ ...visibleFilter, status: "in-progress" }),
      Ticket.countDocuments({ ...visibleFilter, status: "resolved" }),
      Ticket.countDocuments({ ...visibleFilter, status: "closed" }),
      Ticket.countDocuments({
        ...visibleFilter,
        priority: "high",
        status: { $nin: ["resolved", "closed"] },
      }),
    ]);

    res.json({ total, open, inProgress, resolved, closed, highPriority });
  } catch (error) {
    next(error);
  }
}

export async function getTicket(req: Request, res: Response, next: NextFunction) {
  try {
    const id = parseId(req, res);
    if (!id) return;
    const ticket = await Ticket.findOne(visibleTicketQuery(id, req.user!)).populate(populatedTicket);
    if (!ticket) {
      res.status(404).json({ message: "Ticket not found" });
      return;
    }
    res.json(ticket);
  } catch (error) {
    next(error);
  }
}

export async function createTicket(req: Request, res: Response, next: NextFunction) {
  try {
    if (!isRecord(req.body)) {
      invalidBody(res);
      return;
    }
    if (rejectUnknownFields(req.body, ["title", "description", "priority"])) {
      res.status(400).json({ message: "Only title, description, and priority can be provided" });
      return;
    }
    const { title, description, priority = "medium" } = req.body;
    if (typeof title !== "string" || title.trim().length < 5 || title.trim().length > 12) {
      res.status(400).json({ message: "Title must be between 5 and 12 characters" });
      return;
    }
    if (typeof description !== "string" || !description.trim() || description.trim().length > 5000) {
      res.status(400).json({ message: "Description is required and must be 5000 characters or fewer" });
      return;
    }
    if (typeof priority !== "string" || !ticketPriorities.includes(priority as TicketPriority)) {
      res.status(400).json({ message: "Priority must be low, medium, or high" });
      return;
    }

    const ticket = await Ticket.create({
      title: title.trim(),
      description: description.trim(),
      priority: priority as TicketPriority,
      status: "open",
      createdBy: req.user!.id,
    });
    await ticket.populate(populatedTicket);
    res.status(201).json(ticket);
  } catch (error) {
    next(error);
  }
}

export async function updateTicket(req: Request, res: Response, next: NextFunction) {
  try {
    const id = parseId(req, res);
    if (!id) return;
    if (!isRecord(req.body)) {
      invalidBody(res);
      return;
    }
    if (
      Object.keys(req.body).length === 0 ||
      rejectUnknownFields(req.body, ["status", "priority"])
    ) {
      res.status(400).json({ message: "Provide only a status or priority to update" });
      return;
    }
    if (
      req.body.status !== undefined &&
      (typeof req.body.status !== "string" || !ticketStatuses.includes(req.body.status as TicketStatus))
    ) {
      res.status(400).json({ message: "Status must be open, in-progress, resolved, or closed" });
      return;
    }
    if (
      req.body.priority !== undefined &&
      (typeof req.body.priority !== "string" || !ticketPriorities.includes(req.body.priority as TicketPriority))
    ) {
      res.status(400).json({ message: "Priority must be low, medium, or high" });
      return;
    }

    const ticket = await Ticket.findOneAndUpdate(visibleTicketQuery(id, req.user!), req.body, {
      returnDocument: "after",
      runValidators: true,
    }).populate(populatedTicket);
    if (!ticket) {
      res.status(404).json({ message: "Ticket not found" });
      return;
    }
    res.json(ticket);
  } catch (error) {
    next(error);
  }
}

export async function assignTicketToSelf(req: Request, res: Response, next: NextFunction) {
  try {
    const id = parseId(req, res);
    if (!id) return;
    if (req.body !== undefined && (!isRecord(req.body) || Object.keys(req.body).length > 0)) {
      res.status(400).json({ message: "This endpoint does not accept a request body" });
      return;
    }
    const ticket = await Ticket.findOneAndUpdate(
      { _id: id },
      { assignedTo: req.user!.id },
      { returnDocument: "after", runValidators: true },
    ).populate(populatedTicket);
    if (!ticket) {
      res.status(404).json({ message: "Ticket not found" });
      return;
    }
    res.json(ticket);
  } catch (error) {
    next(error);
  }
}

export async function addTicketComment(req: Request, res: Response, next: NextFunction) {
  try {
    const id = parseId(req, res);
    if (!id) return;
    if (!isRecord(req.body)) {
      invalidBody(res);
      return;
    }
    if (rejectUnknownFields(req.body, ["text"]) || typeof req.body.text !== "string") {
      res.status(400).json({ message: "Provide a text field for the comment" });
      return;
    }
    const text = req.body.text.trim();
    if (!text || text.length > 2000) {
      res.status(400).json({ message: "Comment text must be between 1 and 2000 characters" });
      return;
    }
    const ticket = await Ticket.findOne(visibleTicketQuery(id, req.user!));
    if (!ticket) {
      res.status(404).json({ message: "Ticket not found" });
      return;
    }
    ticket.comments.push({
      text,
      author: new mongoose.Types.ObjectId(req.user!.id),
      createdAt: new Date(),
    });
    await ticket.save();
    await ticket.populate(populatedTicket);
    res.status(201).json(ticket);
  } catch (error) {
    next(error);
  }
}

export async function deleteTicket(req: Request, res: Response, next: NextFunction) {
  try {
    const id = parseId(req, res);
    if (!id) return;
    const deleted = await Ticket.findOneAndDelete({
      _id: id,
      createdBy: req.user!.id,
      status: "open",
    });
    if (deleted) {
      res.status(204).end();
      return;
    }

    const ownedTicket = await Ticket.exists({ _id: id, createdBy: req.user!.id });
    if (!ownedTicket) {
      res.status(404).json({ message: "Ticket not found" });
      return;
    }
    res.status(409).json({ message: "Only open tickets can be deleted" });
  } catch (error) {
    next(error);
  }
}
