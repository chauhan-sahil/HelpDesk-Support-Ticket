import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import mongoose from "mongoose";
import { User, UserRole } from "../models/User";

dotenv.config();

interface SeedAccount {
  name: string;
  email: string;
  password: string;
  role: UserRole;
}

function readAccount(prefix: string, role: UserRole): SeedAccount {
  const name = process.env[`${prefix}_NAME`]?.trim();
  const email = process.env[`${prefix}_EMAIL`]?.trim().toLowerCase();
  const password = process.env[`${prefix}_PASSWORD`];
  if (!name || name.length < 2 || name.length > 100) {
    throw new Error(`${prefix}_NAME must be between 2 and 100 characters`);
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error(`${prefix}_EMAIL must be a valid email address`);
  }
  if (!password || password.length < 12 || Buffer.byteLength(password, "utf8") > 72) {
    throw new Error(`${prefix}_PASSWORD must be 12-72 UTF-8 bytes`);
  }
  return { name, email, password, role };
}

async function seed() {
  const mongoUri = process.env.MONGODB_URI;
  if (!mongoUri) throw new Error("MONGODB_URI is required to seed users");

  const accounts = [
    readAccount("ADMIN", "admin"),
    readAccount("SEED_AGENT", "agent"),
    readAccount("SEED_EMPLOYEE_1", "employee"),
    readAccount("SEED_EMPLOYEE_2", "employee"),
  ];
  if (new Set(accounts.map((account) => account.email)).size !== accounts.length) {
    throw new Error("Seed account emails must be unique");
  }

  await mongoose.connect(mongoUri);
  for (const account of accounts) {
    const passwordHash = await bcrypt.hash(account.password, 12);
    await User.findOneAndUpdate(
      { email: account.email },
      {
        $set: { name: account.name, role: account.role },
        $setOnInsert: { email: account.email, passwordHash },
      },
      { upsert: true, returnDocument: "after", runValidators: true, setDefaultsOnInsert: true },
    );
    console.info(`Seeded ${account.role}: ${account.email}`);
  }
}

seed()
  .catch((error: unknown) => {
    console.error("Failed to seed HelpDesk Lite users:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect();
  });
