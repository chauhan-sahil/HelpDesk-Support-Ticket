import { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { User, UserRole } from "../models/User";

export interface AuthenticatedUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

export function jwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret || Buffer.byteLength(secret) < 32) {
    throw new Error("JWT_SECRET must be set to a random value of at least 32 characters.");
  }
  return secret;
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authorization = req.header("Authorization");
  if (!authorization?.startsWith("Bearer ")) {
    res.status(401).json({ message: "Sign in to continue" });
    return;
  }

  try {
    const token = authorization.slice("Bearer ".length);
    const payload = jwt.verify(token, jwtSecret());
    if (typeof payload === "string" || typeof payload.sub !== "string") {
      res.status(401).json({ message: "Invalid or expired session" });
      return;
    }
    const user = await User.findById(payload.sub).select("name email role");
    if (!user) {
      res.status(401).json({ message: "Invalid or expired session" });
      return;
    }
    req.user = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    };
    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError || error instanceof jwt.TokenExpiredError) {
      res.status(401).json({ message: "Invalid or expired session" });
      return;
    }
    next(error);
  }
}

export function requireRoles(...roles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      res.status(401).json({ message: "Sign in to continue" });
      return;
    }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ message: "You do not have permission to perform this action" });
      return;
    }
    next();
  };
}
