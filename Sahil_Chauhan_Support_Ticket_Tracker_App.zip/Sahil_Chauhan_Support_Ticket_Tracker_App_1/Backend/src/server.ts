import cors from "cors";
import dotenv from "dotenv";
import express, { ErrorRequestHandler } from "express";
import mongoose from "mongoose";
import { seedAdmin } from "./controllers/authController";
import { jwtSecret, requireAuth } from "./middleware/auth";
import authRoutes from "./routes/authRoutes";
import ticketRoutes from "./routes/ticketRoutes";
import userRoutes from "./routes/userRoutes";

dotenv.config();

const app = express();
const port = Number(process.env.PORT) || 5000;
const mongoUri = process.env.MONGODB_URI ?? "";

if (!mongoUri) {
  throw new Error("MONGODB_URI is required. Add it to Backend/.env before starting the API.");
}

app.use(cors({ origin: process.env.FRONTEND_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "32kb" }));

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});
app.use("/api/auth", authRoutes);
app.use("/api/tickets", ticketRoutes);
app.use("/api/users", requireAuth, userRoutes);

app.use((_req, res) => {
  res.status(404).json({ message: "Route not found" });
});

const errorHandler: ErrorRequestHandler = (error, _req, res, _next) => {
  if (error instanceof SyntaxError && "body" in error) {
    res.status(400).json({ message: "Request body must be valid JSON" });
    return;
  }
  if (error instanceof mongoose.Error.ValidationError || error instanceof mongoose.Error.CastError) {
    res.status(400).json({ message: error.message });
    return;
  }
  if (error instanceof mongoose.mongo.MongoServerError && error.code === 11000) {
    res.status(409).json({ message: "A record with the provided unique value already exists" });
    return;
  }
  if (typeof error === "object" && error !== null && "type" in error && error.type === "entity.too.large") {
    res.status(413).json({ message: "Request body is too large" });
    return;
  }
  console.error("API request failed:", error);
  res.status(500).json({ message: "An unexpected server error occurred" });
};
app.use(errorHandler);

async function startServer() {
  jwtSecret();
  await mongoose.connect(mongoUri);
  await seedAdmin();
  app.listen(port, () => {
    console.log(`HelpDesk Lite API listening on port ${port}`);
  });
}

startServer().catch((error: unknown) => {
  console.error("Failed to start HelpDesk Lite API:", error);
  process.exitCode = 1;
});
