import { Router } from "express";
import {
  addTicketComment,
  assignTicketToSelf,
  createTicket,
  deleteTicket,
  getTicket,
  getTicketStats,
  listTickets,
  updateTicket,
} from "../controllers/ticketController";
import { requireAuth, requireRoles } from "../middleware/auth";

const router = Router();

router.use(requireAuth);
router.get("/stats", getTicketStats);
router.get("/", listTickets);
router.post("/", createTicket);
router.get("/:id", getTicket);
router.post("/:id/comments", addTicketComment);
router.patch("/:id/assignment", requireRoles("agent", "admin"), assignTicketToSelf);
router.patch("/:id", requireRoles("agent", "admin"), updateTicket);
router.delete("/:id", deleteTicket);

export default router;
