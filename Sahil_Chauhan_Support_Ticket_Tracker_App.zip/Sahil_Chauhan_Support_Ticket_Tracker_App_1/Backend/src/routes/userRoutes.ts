import { Router } from "express";
import { listUsers, updateUserRole } from "../controllers/authController";
import { requireRoles } from "../middleware/auth";

const router = Router();

router.use(requireRoles("admin"));
router.get("/", listUsers);
router.patch("/:id/role", updateUserRole);

export default router;
