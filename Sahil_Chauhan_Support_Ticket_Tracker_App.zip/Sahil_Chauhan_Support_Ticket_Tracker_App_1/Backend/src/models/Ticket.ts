import { HydratedDocument, model, Schema, Types } from "mongoose";

export const ticketStatuses = ["open", "in-progress", "resolved", "closed"] as const;
export const ticketPriorities = ["low", "medium", "high"] as const;

export type TicketStatus = (typeof ticketStatuses)[number];
export type TicketPriority = (typeof ticketPriorities)[number];

export interface TicketComment {
  text: string;
  author: Types.ObjectId;
  createdAt: Date;
}

export interface TicketFields {
  title: string;
  description: string;
  priority: TicketPriority;
  status: TicketStatus;
  createdBy: Types.ObjectId;
  assignedTo: Types.ObjectId | null;
  comments: TicketComment[];
  createdAt: Date;
  updatedAt: Date;
}

export type TicketDocument = HydratedDocument<TicketFields>;

const commentSchema = new Schema<TicketComment>(
  {
    text: { type: String, required: true, trim: true, maxlength: 2000 },
    author: { type: Schema.Types.ObjectId, ref: "User", required: true },
  },
  { timestamps: { createdAt: true, updatedAt: false } },
);

const ticketSchema = new Schema<TicketFields>(
  {
    title: { type: String, required: true, trim: true, minlength: 5, maxlength: 120 },
    description: { type: String, required: true, trim: true, maxlength: 5000 },
    priority: { type: String, enum: ticketPriorities, default: "medium" },
    status: { type: String, enum: ticketStatuses, default: "open" },
    createdBy: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
    assignedTo: { type: Schema.Types.ObjectId, ref: "User", default: null },
    comments: { type: [commentSchema], default: [] },
  },
  { timestamps: true },
);

export const Ticket = model<TicketFields>("Ticket", ticketSchema);
