import { HydratedDocument, model, Schema } from "mongoose";

export const userRoles = ["employee", "agent", "admin"] as const;
export type UserRole = (typeof userRoles)[number];

export interface UserFields {
  name: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  createdAt: Date;
  updatedAt: Date;
}

export type UserDocument = HydratedDocument<UserFields>;

const userSchema = new Schema<UserFields>(
  {
    name: { type: String, required: true, trim: true, maxlength: 100 },
    email: { type: String, required: true, trim: true, lowercase: true, unique: true, maxlength: 254 },
    passwordHash: { type: String, required: true, select: false },
    role: { type: String, enum: userRoles, required: true, default: "employee" },
  },
  { timestamps: true },
);

export const User = model<UserFields>("User", userSchema);
